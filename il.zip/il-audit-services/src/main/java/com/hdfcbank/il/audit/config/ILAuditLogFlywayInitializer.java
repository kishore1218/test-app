package com.hdfcbank.il.audit.config;

import com.fyndna.infra.config.AbstractInfraInitializer;
import lombok.Setter;
import org.flywaydb.core.Flyway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

import java.lang.invoke.MethodHandles;

/**
 * @author Venkat
 */
@Configuration
public class ILAuditLogFlywayInitializer extends AbstractInfraInitializer {

  public static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

  @Setter
  @Autowired(required = false)
  private Flyway flyway;

  @Bean
  public WebClient webClient() {
    return WebClient.create();
  }

  @Override
  public void initialize() {
    LOGGER.info("Enter into ILAuditLogFlywayInitializer");
    if (flyway != null) {
      runFlywayForApp();
    }
    LOGGER.info("Exit from ILAuditLogFlywayInitializer");
  }
}
