package com.hdfcbank.il.audit.enums;

/**
 * @author venkat
 */
public enum PubsubProcessingStatus {
    /** Message is processed successfully */
    SUCCESS,
    /** Message to be retried by Dapr */
    RETRY,
    /** Warning is logged and message is dropped */
    DROP
}
