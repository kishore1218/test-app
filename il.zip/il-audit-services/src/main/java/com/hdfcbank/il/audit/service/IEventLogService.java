package com.hdfcbank.il.audit.service;

import com.hdfcbank.il.audit.dto.EventLogDto;
import com.hdfcbank.il.audit.entity.EventLogEntity;

/**
 * @author venkat
 */
public interface IEventLogService {
    EventLogEntity findEventTypeByTxnId(String txnId);
    EventLogEntity save(EventLogDto eventLogDto);
}
