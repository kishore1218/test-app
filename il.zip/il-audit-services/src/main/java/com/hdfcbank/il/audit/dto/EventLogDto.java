package com.hdfcbank.il.audit.dto;

import com.fyndna.dtolib.dto.AbstractDomainDTO;
import lombok.Builder;
import lombok.Data;

import java.time.ZonedDateTime;

/**
 * @author venkat
 */
@Data
@Builder
public class EventLogDto extends AbstractDomainDTO {

    private String traceId;
    private ZonedDateTime physicalTimeOfEvent;
    private String txnId;
    private String eventType;
    private String rrNum;

    @Override
    public Object getId() {
        return this.txnId;
    }
}
