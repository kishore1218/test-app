package com.hdfcbank.il.audit.service;

import com.fyndna.infra.service.AbstractService;
import com.hdfcbank.il.audit.dto.AuditLogDto;
import com.hdfcbank.il.audit.entity.AuditLogEntity;
import com.hdfcbank.il.audit.mapper.AuditLogMapper;
import com.hdfcbank.il.audit.repository.AuditLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author venkat
 */
@Slf4j
@Service
public class AuditLogService extends AbstractService<AuditLogRepository, AuditLogEntity, String> implements IAuditLogService{

    private final AuditLogMapper mapper;

    public AuditLogService(
            AuditLogRepository repository, AuditLogMapper mapper) {
        super(repository);
        this.mapper = mapper;
    }

    @Override
    public AuditLogEntity findDestinationById(String txnId){
        AuditLogEntity iLInterfaceLogEntity = findById(txnId);
        return iLInterfaceLogEntity;
    }

    public AuditLogEntity save(AuditLogDto auditLogDto) {
        AuditLogEntity auditLogEntity = mapper.fromDto(auditLogDto);
        log.debug("Create audit logs for DestSystem : {}, TxnId : {}",
                auditLogEntity.getDestSystem(),
                auditLogEntity.getTxnId());
        auditLogEntity =super.create(auditLogEntity);
        log.debug(
                "Successfully Created audit logs for  DestSystem : {}, TxnId : {}",
                auditLogEntity.getDestSystem(),
                auditLogEntity.getTxnId());
        return auditLogEntity;
    }
}
