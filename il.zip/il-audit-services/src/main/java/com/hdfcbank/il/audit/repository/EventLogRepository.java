package com.hdfcbank.il.audit.repository;

import com.fyndna.infra.repository.AbstractRepository;
import com.hdfcbank.il.audit.entity.EventLogEntity;
import org.springframework.stereotype.Repository;

/**
 * @author venkat
 */
@Repository
public interface EventLogRepository extends AbstractRepository<EventLogEntity, String> {}
