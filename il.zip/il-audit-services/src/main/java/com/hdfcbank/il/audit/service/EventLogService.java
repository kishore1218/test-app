package com.hdfcbank.il.audit.service;

import com.fyndna.infra.service.AbstractService;
import com.hdfcbank.il.audit.dto.EventLogDto;
import com.hdfcbank.il.audit.entity.EventLogEntity;
import com.hdfcbank.il.audit.mapper.EventLogMapper;
import com.hdfcbank.il.audit.repository.EventLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author venkat
 */
@Slf4j
@Service
public class EventLogService extends AbstractService<EventLogRepository, EventLogEntity, String> implements IEventLogService{

    private final EventLogMapper mapper;

    public EventLogService(
            EventLogRepository repository, EventLogMapper mapper) {
        super(repository);
        this.mapper = mapper;
    }

    @Override
    public EventLogEntity findEventTypeByTxnId(String txnId){
        EventLogEntity eventLogEntity = findById(txnId);
        return eventLogEntity;
    }

    public EventLogEntity save(EventLogDto eventLogDto) {
        EventLogEntity eventLogEntity = mapper.fromDto(eventLogDto);
        log.debug("Create event logs for traceId : {} and txnId : {}",
                eventLogDto.getTraceId(),
                eventLogDto.getTxnId());
        eventLogEntity =super.create(eventLogEntity);
        log.debug(
                "Successfully Created Interface logs for traceId : {}, and txnId : {}",
                eventLogEntity.getTraceId(),
                eventLogEntity.getTxnId());
        return eventLogEntity;
    }
}
