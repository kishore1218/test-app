package com.hdfcbank.il.audit.controller;


import com.hdfcbank.il.audit.dto.AuditLogDto;
import com.hdfcbank.il.audit.enums.PubsubProcessingStatus;
import com.hdfcbank.il.audit.service.IAuditLogService;
import io.dapr.client.domain.CloudEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author venkat
 */
@Slf4j
@RequiredArgsConstructor
@RestController
public class AuditLogController {

  private final IAuditLogService auditLogService;


  @PostMapping("/il/audit/log")
  public void logAuditRequest(@RequestBody AuditLogDto auditLogDto) {
    auditLogService.save(auditLogDto);
  }

  @PostMapping(path = "/pubsub/subscriber/il/audit")
  public ResponseEntity<String> logAsyncILAuditRequest(
      @RequestBody CloudEvent<AuditLogDto> body) {
    //body.getType()
    AuditLogDto auditLogDto = body.getData();
    String resStr= null;
    try {
      log.debug("Log received. TxnId: {}", auditLogDto.getTxnId());
      auditLogService.save(auditLogDto);
      resStr = PubsubProcessingStatus.SUCCESS.name();
    } catch (Exception e) {
      log.error(Exception.class.getSimpleName() + "while Failed to store audit log. "  + " for auditLogDto = {}", auditLogDto, e);
      resStr = PubsubProcessingStatus.DROP.name();
    }
    return ResponseEntity.ok(resStr);
  }
}
