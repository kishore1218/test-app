package com.hdfcbank.il.audit.entity;

import com.fyndna.infra.entity.AbstractBaseEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.ZonedDateTime;

/**
 * @author venkat
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "il_audit_log")
@Entity
public class AuditLogEntity extends AbstractBaseEntity<String> {

    @Id
    @Column(name = "txn_id_uuid")
    String txnId;

    @Column(name = "txn_date_time")
    ZonedDateTime txnDateTime;

    @Column(name = "txn_type")
    String txnType;

    @Column(name = "network_type")
    String networkType;

    @Column(name = "req_type")
    String reqType;

    @Column(name = "dest_system")
    String destSystem;


    @Override
    public String getId() {
        return this.txnId;
    }
}
