package com.hdfcbank.il.audit.mapper;

import com.hdfcbank.il.audit.dto.AuditLogDto;
import com.hdfcbank.il.audit.entity.AuditLogEntity;
import org.mapstruct.Mapper;

/**
 * @author venkat
 */
@Mapper(componentModel = "spring")
public interface AuditLogMapper {
  AuditLogEntity fromDto(AuditLogDto dto);
}
