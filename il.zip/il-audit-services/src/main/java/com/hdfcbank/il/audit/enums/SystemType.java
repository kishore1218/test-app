package com.hdfcbank.il.audit.enums;

/**
 * @author venkat
 */
public enum SystemType {

    NPCI,
    FYN_SWITCH,
    FC_SWITCH;

    private SystemType() {
    }
}
