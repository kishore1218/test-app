package com.hdfcbank.il.audit.dto;

import com.fyndna.dtolib.dto.AbstractDomainDTO;
import com.hdfcbank.il.audit.enums.IntegrationSystemApiName;
import com.hdfcbank.il.audit.enums.SystemType;
import lombok.Builder;
import lombok.Data;

import java.time.ZonedDateTime;

/**
 * @author venkat
 */
@Data
@Builder
public class AuditLogDto  extends AbstractDomainDTO {

    private String traceId;
    private SystemType destSystem;
    private IntegrationSystemApiName reqType;
    private ZonedDateTime txnDateTime;
    private String txnId;
    private String txnType;
    private String networkType;

    @Override
    public Object getId() {
        return this.txnId;
    }
}
