package com.hdfcbank.il.audit.entity;

import com.fyndna.infra.entity.AbstractBaseEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.ZonedDateTime;

/**
 * @author venkat
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "il_interface_log")
@Entity
public class EventLogEntity extends AbstractBaseEntity<String> {

    @Id
    @Column(name = "txn_id_uuid")
    String txnId;

    @Column(name = "physical_time_of_event")
    ZonedDateTime physicalTimeOfEvent;

    @Column(name = "trace_id")
    String traceId;

    @Column(name = "event_type")
    String eventType;

    @Column(name = "rr_num")
    String rrNum;

    @Override
    public String getId() {
        return this.txnId;
    }
}
