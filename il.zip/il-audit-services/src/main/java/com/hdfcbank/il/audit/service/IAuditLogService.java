package com.hdfcbank.il.audit.service;

import com.hdfcbank.il.audit.dto.AuditLogDto;
import com.hdfcbank.il.audit.entity.AuditLogEntity;

/**
 * @author venkat
 */
public interface IAuditLogService {
    AuditLogEntity findDestinationById(String txnId);
    AuditLogEntity save(AuditLogDto ilInterfaceLogDto);
}
