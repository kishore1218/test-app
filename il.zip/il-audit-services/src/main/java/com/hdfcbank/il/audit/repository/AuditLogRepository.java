package com.hdfcbank.il.audit.repository;

import com.fyndna.infra.repository.AbstractRepository;
import com.hdfcbank.il.audit.entity.AuditLogEntity;
import org.springframework.stereotype.Repository;

/**
 * @author venkat
 */
@Repository
public interface  AuditLogRepository extends AbstractRepository<AuditLogEntity, String> {}
