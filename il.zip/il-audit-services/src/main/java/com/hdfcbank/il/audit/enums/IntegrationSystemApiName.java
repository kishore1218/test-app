package com.hdfcbank.il.audit.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author venkat
 */
public enum IntegrationSystemApiName {
    GENERATE_OTP("GenerateOtp"),
    VERIFY_OTP("VerifyOtp"),
    SMS_SERVICE("SmsService"),
    DEBIT_CARD_PIN_VERIFICATION("DebitCardPinVerification"),
    DEBIT_CARD_VALIDATION("DebitCardValidation"),
    CUST_ID_ENQUIRY_FOR_MOBILE("CustIdEnquiryForMobile"),
    TOKENIZE_ACCOUNT_PARAMETERS("TokenizeAccountParameters"),
    UNTOKENIZE_ACCOUNT_PARAMETERS("UntokenizeAccountParameters"),
    SAVE_UPI_PIN_DETAILS("SaveUpiPinDetails"),
    VALIDATE_AND_UPDATE_UPI_PIN_DETAILS("ValidateAndUpdateUpiPinDetails"),
    RESP_LIST_ACCOUNT("RespListAccount"),
    RESP_OTP("RespOtp"),
    RESP_REG_MOB("RespRegMob"),
    RESP_SET_CRE("RespSetCre"),
    REG_SWITCH("RegSwitch"),
    REQ_PAY("ReqPay"),
    RESP_PAY("RespPay"),
    REQ_VAL_ADD("ReqValAdd"),
    RESP_VAL_ADD("RespValAdd"),
    REQ_CHK_TXN("ReqChkTxn"),
    RESP_CHK_TXN("RespChkTxn"),
    REQ_HBT("ReqHbt"),
    RESP_HBT("RespHbt"),
    CREDIT("creditFunds"),
    FETCH_TXN_STATUS("fetchTransactionStatus"),
    FETCH_ACC_HOLDERS("fetchAccountHolders"),
    FETCH_PRODUCT_CLASS("fetchProductClass"),
    FETCH_REAL_ACCOUNT("fetchRealAccount"),
    FETCH_CUSTOMER_DETAILS("fetchCustomerDetails"),
    PUBLISH_FINANCIAL_TRANSACTION("publishFinancialTransaction"),
    NOT_SPECIFIED("NotSpecified"),
    EMAIL_SMS_DISPATCH_SERVICE("EmailSmsDispatchService"),
    DELIVER_ALERT("DeliverAlert"),
    EXECUTE_RULE("ExecuteRule"),
    FETCH_STANDIN_TXN_STATUS("fetchStandinTransactionStatus"),
    VALIDATE_CREDIT_TRANSACTION("validateCreditTransaction"),
    PROCESS_STANDIN_CREDIT("processStandinCredit"),
    NOTIFY_PRODUCT_PROCESSOR_AVAILABILITY("NotifyProductProcessorAvailability"),
    FETCH_PRODUCT_PROCESSOR_AVAILABILITY("fetchProductProcessorAvailability"),
    GENERATE_SETTLEMENT_REPORT("generateSettlementReport");

    private static final Map<String, IntegrationSystemApiName> LOOKUP = (Map) Arrays.stream(values()).collect(Collectors.toMap(IntegrationSystemApiName::getApiName, Function.identity()));
    private final String apiName;

    private IntegrationSystemApiName(String apiName) {
        this.apiName = apiName;
    }

    public static IntegrationSystemApiName fromApiName(String apiName) {
        return (IntegrationSystemApiName)LOOKUP.get(apiName);
    }

    public String getApiName() {
        return this.apiName;
    }
}
