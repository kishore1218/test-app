package com.hdfcbank.il.audit;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author venkat
 */
@EnableCaching
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class})
@ComponentScan(basePackages = "com.fyndna")
@EntityScan(basePackages = "com.fyndna")
@EnableJpaRepositories(basePackages = "com.fyndna")
@OpenAPIDefinition(
    info =
        @Info(
            title = "IL Audit Log Service",
            version = "1.0",
            description = "Documentation IL Audit Log Service API v1.0"))
public class ILAuditLogApplication {

  public static void main(String[] args) {
    SpringApplication.run(ILAuditLogApplication.class, args);
  }
}
