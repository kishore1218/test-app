package com.hdfcbank.il.audit.mapper;

import com.hdfcbank.il.audit.dto.EventLogDto;
import com.hdfcbank.il.audit.entity.EventLogEntity;
import org.mapstruct.Mapper;

/**
 * @author venkat
 */
@Mapper(componentModel = "spring")
public interface EventLogMapper {
  EventLogEntity fromDto(EventLogDto dto);
}
