CREATE TABLE IF NOT EXISTS il_audit_log (
 txn_date_time timestamp,
 txn_id uuid primary key,
 message_direction text,
 network_type text,
 api_name text,
 system text,
 rr_num text,
 trace_id text,
 physical_time_of_event timestamp
)
PARTITION BY RANGE (txn_date_time);

CREATE TABLE IF NOT EXISTS il_audit_log_default PARTITION OF il_interface_log DEFAULT;

CREATE INDEX txn_id_rr_num_il_audit_log ON il_audit_log(txn_id, rr_num) INCLUDE (system);


CREATE TABLE il_audit_log_2023_01 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-01-01') TO ('2023-02-01');

CREATE TABLE il_audit_log_2023_02 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-02-01') TO ('2023-03-01');

CREATE TABLE il_audit_log_2023_03 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-03-01') TO ('2023-04-01');

CREATE TABLE il_audit_log_2023_04 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-04-01') TO ('2023-05-01');

CREATE TABLE il_audit_log_2023_05 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-05-01') TO ('2023-06-01');

CREATE TABLE il_audit_log_2023_06 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-06-01') TO ('2023-07-01');

CREATE TABLE il_audit_log_2023_07 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-07-01') TO ('2023-08-01');

CREATE TABLE il_audit_log_2023_08 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-08-01') TO ('2023-09-01');

CREATE TABLE il_audit_log_2023_09 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023–09-01') TO ('2023-10-01');

CREATE TABLE il_audit_log_2023_10 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-10-01') TO ('2023-11-01');

CREATE TABLE il_audit_log_2023_11 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-11-01') TO ('2023-12-01');

CREATE TABLE il_audit_log_2023_12 PARTITION OF il_audit_log
  FOR VALUES FROM ('2023-12-01') TO ('2024-01-01');

