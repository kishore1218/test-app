CREATE TABLE event_log (
txn_id uuid primary key,
event_type text,
rr_num text,
trace_id text,
physical_time_of_event timestamp
)
PARTITION BY RANGE (physical_time_of_event);


CREATE TABLE IF NOT EXISTS event_log_default PARTITION OF event_log DEFAULT;

CREATE INDEX txn_id_rr_num_event_log ON event_log(txn_id, rr_num) INCLUDE (event_type);


CREATE TABLE event_log_2023_01 PARTITION OF event_log
  FOR VALUES FROM ('2023-01-01') TO ('2023-02-01');

CREATE TABLE event_log_2023_02 PARTITION OF event_log
  FOR VALUES FROM ('2023-02-01') TO ('2023-03-01');

CREATE TABLE event_log_2023_03 PARTITION OF event_log
  FOR VALUES FROM ('2023-03-01') TO ('2023-04-01');

CREATE TABLE event_log_2023_04 PARTITION OF event_log
  FOR VALUES FROM ('2023-04-01') TO ('2023-05-01');

CREATE TABLE event_log_2023_05 PARTITION OF event_log
  FOR VALUES FROM ('2023-05-01') TO ('2023-06-01');

CREATE TABLE event_log_2023_06 PARTITION OF event_log
  FOR VALUES FROM ('2023-06-01') TO ('2023-07-01');

CREATE TABLE event_log_2023_07 PARTITION OF event_log
  FOR VALUES FROM ('2023-07-01') TO ('2023-08-01');

CREATE TABLE event_log_2023_08 PARTITION OF event_log
  FOR VALUES FROM ('2023-08-01') TO ('2023-09-01');

CREATE TABLE event_log_2023_09 PARTITION OF event_log
  FOR VALUES FROM ('2023–09-01') TO ('2023-10-01');

CREATE TABLE event_log_2023_10 PARTITION OF event_log
  FOR VALUES FROM ('2023-10-01') TO ('2023-11-01');

CREATE TABLE event_log_2023_11 PARTITION OF event_log
  FOR VALUES FROM ('2023-11-01') TO ('2023-12-01');

CREATE TABLE event_log_2023_12 PARTITION OF event_log
  FOR VALUES FROM ('2023-12-01') TO ('2024-01-01');

