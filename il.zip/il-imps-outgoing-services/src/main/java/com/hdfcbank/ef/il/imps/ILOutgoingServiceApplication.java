package com.hdfcbank.ef.il.imps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ILOutgoingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ILOutgoingServiceApplication.class, args);
	}

}
