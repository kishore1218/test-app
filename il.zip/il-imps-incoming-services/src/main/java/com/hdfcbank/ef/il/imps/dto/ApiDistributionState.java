package com.hdfcbank.ef.il.imps.dto;

import com.hdfcbank.il.core.dto.DistributionState;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.time.ZonedDateTime;

@Configuration
@Data
@Slf4j
public class ApiDistributionState {

    @Value("${distribution.value}")
    Integer distributionValue;

    @PostConstruct
    public void initDistributionState(){
        DistributionState newSystem = new DistributionState();
        newSystem.setLowerMod(0);
        newSystem.setUpperMod(distributionValue-1);
        DistributionState oldSystem = new DistributionState();
        oldSystem.setLowerMod(distributionValue);
        oldSystem.setUpperMod(100);

        this.currentState = new DistributionState[2];
        this.currentState[0] = newSystem;
        this.currentState[1] = oldSystem;

        log.info("CURRENT STATE INITIATED");
    }


    DistributionState[] currentState;
    DistributionState[] previousState;
    ZonedDateTime stateActivationTime;
}
