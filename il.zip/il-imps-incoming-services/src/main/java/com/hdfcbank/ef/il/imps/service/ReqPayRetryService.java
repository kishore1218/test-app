package com.hdfcbank.ef.il.imps.service;

import com.hdfcbank.ef.il.imps.model.ApiConfig;
import com.hdfcbank.ef.il.imps.strategy.AuditLogStrategy;
import com.hdfcbank.il.core.annotation.AuditLog;
import com.hdfcbank.il.core.exception.ApiException;
import com.hdfcbank.il.core.model.ApiRequest;
import com.hdfcbank.il.core.model.ApiResponse;
import com.hdfcbank.il.core.service.ApiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 *
 */
@Slf4j
@Service
public class ReqPayRetryService {

    @Autowired
    @AuditLog(strategy = AuditLogStrategy.class)
    private ApiService apiService;

    @Autowired
    private ApiConfig config;


    /**
     *
     * @param ex
     * @param request
     * @return
     * @throws Exception
     */
    public<T1,T2> ApiResponse<T2> retry(ApiRequest<T1> request  , ApiException ex) {

        log.info("Retry transaction-{}",request);
        ApiResponse<T2> response=null;

        switch (config.getRetryMode()) {
            case "1" -> throw ex;
            case "2" -> {
                if(!config.getDominantSystem().equals(request.getHostName())){
                    log.info("Retrying with Dominant system: {}",config.getDominantSystem());
                    request.setHostName(config.getDominantSystem());
                    response= apiService.<T1,T2>process(request);
                }else{
                    log.error("No Dominant System configured..");
                    throw ex;
                }
            }
            case "3" -> {
                if(config.getDominantSystem().equals(request.getHostName())){
                    request.setHostName(config.getLowerSystem());
                }else{
                    request.setHostName(config.getDominantSystem());
                }
                log.info("Retrying with either system -{}",request.getHostName());
                response= apiService.<T1,T2>process(request);
            }
            default -> throw new RuntimeException("Invalid retry config type...");
        };
        return response;
    }
}
