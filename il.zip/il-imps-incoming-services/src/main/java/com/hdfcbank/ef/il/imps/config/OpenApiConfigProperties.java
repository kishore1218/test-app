package com.hdfcbank.ef.il.imps.config;

import lombok.Data;

import java.util.List;

/**
 *
 */
@Data
public class OpenApiConfigProperties {
    private String title;
	private String version;
    private String description;
    private String contactName;
    private String contactEmail;
    private List<String> servers;

}
