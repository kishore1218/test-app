package com.hdfcbank.ef.il.imps.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import reactor.core.publisher.Mono;

public interface ImpsApiController {


    @Operation(summary="Process Imps reqpay transaction",description = "Processing Req Pay Transaction",responses = {
            @ApiResponse(responseCode = "200",description = "success",content=@Content),
            @ApiResponse(responseCode = "400",description = "Invalid Arguments",content=@Content),
            @ApiResponse(responseCode = "403",description = "Forbidden: Insufficient Access for request operation",content=@Content),
            @ApiResponse(responseCode = "405",description = "Processing error",content=@Content),
            @ApiResponse(responseCode = "410",description = "Application Error",content=@Content),
            @ApiResponse(responseCode = "500",description = "Internal Server Error",content=@Content(schema = @Schema(hidden = true))),
    })
    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/ReqPay/{version}/urn:txnid:{txnId}")
    public ResponseEntity<Mono<com.hdfcbank.il.core.model.ApiResponse<String>>> reqPay(@RequestBody String request,
                                                                                       @PathVariable String txnId)throws Throwable;


    @Operation(summary="Process Imps reqcheckpay transaction",description = "Porcess the Req check Pay transaction",responses = {
            @ApiResponse(responseCode = "200",description = "success",content=@Content),
            @ApiResponse(responseCode = "400",description = "Invalid Arguments",content=@Content),
            @ApiResponse(responseCode = "403",description = "Forbidden: Insufficient Access for request operation",content=@Content),
            @ApiResponse(responseCode = "405",description = "Processing error",content=@Content),
            @ApiResponse(responseCode = "410",description = "Application Error",content=@Content),
            @ApiResponse(responseCode = "500",description = "Internal Server Error",content=@Content(schema = @Schema(hidden = true))),
    })
    @ResponseStatus(HttpStatus.OK)
    @PostMapping(value="/reqcheckpay", consumes = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Mono<com.hdfcbank.il.core.model.ApiResponse<String>>> reqCheckPay(@RequestBody String request)throws Exception;

}
