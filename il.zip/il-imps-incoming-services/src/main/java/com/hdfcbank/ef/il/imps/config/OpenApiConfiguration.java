package com.hdfcbank.ef.il.imps.config;



import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 *
 */
@Configuration
public class OpenApiConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "hdfc.oas")
    public OpenApiConfigProperties openApiConfigProperties(){
        return new OpenApiConfigProperties();
    }

    @Bean
    public OpenAPI openAPI(OpenApiConfigProperties props){

        List<Server> servers= Optional.ofNullable(props.getServers()).map(urls->{
            return urls.stream().map(url->{
                Server server=new Server();
                server.setUrl(url);
                return server;
            }).collect(Collectors.toList());
        }).orElseGet(ArrayList::new);

        OpenAPI openAPI=new OpenAPI()
                .components(new Components())
                .info(new Info()
                        .title(props.getTitle())
                        .description(props.getDescription())
                        .version(props.getVersion())
                        .contact(new Contact()
                                .name(props.getContactName())
                                .email(props.getContactEmail())))
                .servers(servers);
        return openAPI;

    }

}
