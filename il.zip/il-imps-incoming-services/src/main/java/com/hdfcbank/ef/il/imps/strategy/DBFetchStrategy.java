package com.hdfcbank.ef.il.imps.strategy;


import com.hdfcbank.il.core.strategy.RouterStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 *
 */
@Slf4j
@Service
public class DBFetchStrategy implements RouterStrategy<String,String> {

    /**
     *
     * @param tnx
     * @return
     */
    @Override
    public String identifySwitch(String tnx) {
        log.info("DBFetchStrategy: identifying the switch for tnx: {}",tnx);
        //TODO: should actually pull the switch from db by tnx id.
        return null;
    }
}
