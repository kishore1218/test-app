package com.hdfcbank.ef.il.imps.exception;

import java.util.List;

/**
 *
 */
public class ApiServiceException extends Exception{


    public ApiServiceException(String message, Throwable e){
        super(message,e);
    }

    public ApiServiceException(String message){
        super(message);
    }

    public ApiServiceException(){

    }
}
