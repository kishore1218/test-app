package com.hdfcbank.ef.il.imps.strategy;

import com.hdfcbank.ef.il.imps.dto.ApiDistributionState;
import com.hdfcbank.il.core.dto.DistributionState;
import com.hdfcbank.il.core.enums.SystemType;
import com.hdfcbank.il.core.strategy.RouterStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 */
@Slf4j
@Service
public class ModStrategy implements RouterStrategy<String,String> {

    @Autowired
    ApiDistributionState distributionState;
    @Override
    public  String identifySwitch(String transactionId) {

        log.info("identifySwitch: for transaction-{}",transactionId);
        long hashval = hash(transactionId);
        DistributionState[] currentState = distributionState.getCurrentState();
        log.info("identifySwitch: currentState ",currentState[0]);
        int lowerMod = currentState[0].getLowerMod();
        int upperMod = currentState[0].getUpperMod();
        if ((hashval % 1000) < (upperMod* 10L) && (hashval % 1000) >(lowerMod* 10L)){
            return SystemType.NEW.value();
        }
        else {
            return SystemType.OLD.value();
        }
    }

    public long hash(String s) {
        int hash = 0;
        for (int i = 0; i < s.length(); i++) {
            hash = 257*hash + s.charAt(i);
        }
        return Math.abs(hash);
    }
}
