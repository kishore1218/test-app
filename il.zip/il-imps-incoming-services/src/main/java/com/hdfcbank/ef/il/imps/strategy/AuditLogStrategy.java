package com.hdfcbank.ef.il.imps.strategy;

import com.hdfcbank.il.core.audit.IAuditLog;
import com.hdfcbank.il.core.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


/**
 *
 */
@Slf4j
@Service
public class AuditLogStrategy implements IAuditLog {

    /**
     *
     * @param response
     */
    @Override
    public void audit(ApiResponse response) {
        //TODO: Should actually publish to kafka topic
        log.info("Auditing ... response...{}",response);
    }
}
