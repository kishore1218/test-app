package com.hdfcbank.ef.il.imps.model;

import lombok.Builder;
import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
@Builder
public class GenericResponse {

    HttpStatus responseCode;
    String message;
}
