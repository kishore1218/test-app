package com.hdfcbank.ef.il.imps.utils;


/**
 *
 */
public class AppConstants {

    public static final String DO_NOTHING="DO_NOTHING";

    public static final String RETRY_WITH_DOMINANT="RETRY_WITH_DOMINANT";

    public static final String RETRY_WITH_EITHER_SYSTEM="RETRY_WITH_EITHER_SYSTEM";
}
