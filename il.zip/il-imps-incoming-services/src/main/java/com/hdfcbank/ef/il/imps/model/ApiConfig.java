package com.hdfcbank.ef.il.imps.model;

import lombok.Data;


/**
 *
 */
@Data
public class ApiConfig {

    private String dominantSystem;

    private String lowerSystem;

    private String retryMode;

}
