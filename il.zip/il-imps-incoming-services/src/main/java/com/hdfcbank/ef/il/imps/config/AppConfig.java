package com.hdfcbank.ef.il.imps.config;

import com.hdfcbank.ef.il.imps.model.ApiConfig;
import com.hdfcbank.il.core.config.ILCoreConfig;
import com.hdfcbank.il.core.service.ApiService;
import com.hdfcbank.il.core.service.ApiServiceImpl;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 *
 */
@Configuration
@Import({ILCoreConfig.class})
public class AppConfig {


    /**
     *
     * @return
     */
    @Bean(name="apiService")
//    @LoadBalanced(strategy = ModStrategy.class)
//    @AuditLog(strategy = AuditLogStrategy.class)
    ApiService apiService(){
        return new ApiServiceImpl();
    };


    @Bean
    @ConfigurationProperties(prefix = "il.config")
    public ApiConfig apiConfig(){
        return new ApiConfig();
    }


}
