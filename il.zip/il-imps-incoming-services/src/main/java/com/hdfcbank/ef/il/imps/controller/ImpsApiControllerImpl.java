package com.hdfcbank.ef.il.imps.controller;


import com.hdfcbank.ef.il.imps.service.ReqPayRetryService;
import com.hdfcbank.ef.il.imps.strategy.AuditLogStrategy;
import com.hdfcbank.ef.il.imps.strategy.DBFetchStrategy;
import com.hdfcbank.ef.il.imps.strategy.ModStrategy;
import com.hdfcbank.il.core.annotation.AuditLog;
import com.hdfcbank.il.core.annotation.LoadBalanced;
import com.hdfcbank.il.core.exception.ApiException;
import com.hdfcbank.il.core.model.ApiRequest;
import com.hdfcbank.il.core.model.ApiResponse;
import com.hdfcbank.il.core.service.ApiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


@Slf4j
@RestController
@RequestMapping("/imps")
public class ImpsApiControllerImpl implements ImpsApiController{

    @LoadBalanced(strategy = ModStrategy.class)
    @AuditLog(strategy = AuditLogStrategy.class)
    @Autowired
    private ApiService apiService;


    @LoadBalanced(strategy = DBFetchStrategy.class)
    @Autowired
    private ApiService relatedTxnApiService;


    @Autowired
    private ReqPayRetryService retryService;

    @Override
    public ResponseEntity<Mono<ApiResponse<String>>> reqPay(String request, String txnId) throws Throwable{
        log.info("process reqpay: {}",request);
        var req=ApiRequest.<String>builder().body(request).txnId(txnId).build();

        var res=Mono.fromCallable(()->apiService.<String,String>process(req))
                .onErrorResume(ex->{
                    log.info("Error in processing , retrying..... for request-{}",req);
                    return Mono.just(retryService.<String,String>retry(req,new ApiException(ex)));
                 });
        return ResponseEntity.ok(res);
    }

    @Override
    public ResponseEntity<Mono<ApiResponse<String>>> reqCheckPay(String request) throws Exception{
        log.info("process req check pay: {}",request);
        var req=ApiRequest.<String>builder().body(request).build();
        var res=Mono.just(relatedTxnApiService.<String,String>process(req));
        return ResponseEntity.ok(res);
    }

}
