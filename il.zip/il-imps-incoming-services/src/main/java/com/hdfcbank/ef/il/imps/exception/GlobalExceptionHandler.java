package com.hdfcbank.ef.il.imps.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfcbank.ef.il.imps.model.GenericResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Slf4j
@Configuration
@Order(-2)
public class GlobalExceptionHandler implements ErrorWebExceptionHandler {

    ObjectMapper objectMapper=new ObjectMapper();
    /**
     * Handle the given exception. A completion signal through the return value
     * indicates error handling is complete while an error signal indicates the
     * exception is still not handled.
     *
     * @param exchange the current exchange
     * @param ex       the exception to handle
     * @return {@code Mono<Void>} to indicate when exception handling is complete
     */
    @Override
    public Mono<Void> handle(ServerWebExchange exchange, Throwable ex) {

        log.error("Application : error:",ex);
        DataBufferFactory bufferFactory = exchange.getResponse().bufferFactory();
        exchange.getResponse().getHeaders().setContentType(MediaType.TEXT_PLAIN);
        try{
            if(ex instanceof ApiServiceException){
                var exception=(ApiServiceException)ex;
                exchange.getResponse().setStatusCode(HttpStatus.NOT_ACCEPTABLE);
                var res= GenericResponse.builder().responseCode(HttpStatus.NOT_ACCEPTABLE).message("Unable to process request").build();
                DataBuffer dataBuffer = bufferFactory.wrap(objectMapper.writeValueAsBytes(res));
                return exchange.getResponse().writeWith(Mono.just(dataBuffer));
            }
            else{
                exchange.getResponse().setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                var res= GenericResponse.builder().responseCode(HttpStatus.NOT_ACCEPTABLE).message("Unable to process request").build();
                return exchange.getResponse().writeWith(Mono.error(ex));
            }
        }catch(Exception e){
            return exchange.getResponse().writeWith(Mono.error(ex));
        }
    }
}
