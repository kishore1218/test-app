package com.hdfcbank.il.core.utils;

import com.hdfcbank.il.core.annotation.AuditLog;
import com.hdfcbank.il.core.annotation.LoadBalanced;
import com.hdfcbank.il.core.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.BeanFactory;


/**
 *
 */
@Slf4j
public class AuditLogUtils {


    public static<T> void audit(AuditLog annotation, BeanFactory beanFactory, ApiResponse response){
        log.info("Audit log - {}", response);
        var strategy = beanFactory.getBean(annotation.strategy());
        strategy.audit(response);
    }
}
