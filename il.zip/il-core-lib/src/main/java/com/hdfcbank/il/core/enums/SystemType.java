package com.hdfcbank.il.core.enums;

/**
 * @author venkat
 */
public enum SystemType {

    NPCI("NPCI"),
    OLD("OLD"),
    NEW("NEW");

    private final String value;
    SystemType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SystemType fromValue(String v) {
        for (SystemType c: SystemType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
