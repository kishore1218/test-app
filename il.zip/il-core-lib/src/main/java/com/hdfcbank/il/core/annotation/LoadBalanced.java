package com.hdfcbank.il.core.annotation;

import com.hdfcbank.il.core.strategy.RouterStrategy;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 *
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface LoadBalanced {

    Class<? extends RouterStrategy> strategy();

}
