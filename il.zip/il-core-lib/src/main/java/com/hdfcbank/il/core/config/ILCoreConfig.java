package com.hdfcbank.il.core.config;

import lombok.Data;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Data
@Configuration
@ComponentScan(basePackages ="com.hdfcbank.il.core")
public class ILCoreConfig {

    private String eventPubSubName;
    private String topicName;

}
