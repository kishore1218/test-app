package com.hdfcbank.il.core.service;

import com.fyndna.iasyncmessage.service.IPubSubService;
import com.hdfcbank.il.core.config.ILCoreConfig;
import com.hdfcbank.il.core.model.ApiRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static com.hdfcbank.il.core.utils.LoggerUtils.ilLogErrorMessage;


/**
 * @author venkat
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AsyncILInterfaceLoggingService {


    private final ILCoreConfig iLCoreConfig;
    private final IPubSubService pubSubService;
    private final DaprPubsubSubscriber daprPubsubSubscriber;
    private final Executor auditLogTaskExecutor;


    public void log(ApiRequest reqInfo) {
        try {
                log.debug("Publishing event in Kafka with pubsubTopic as {} ", iLCoreConfig.getTopicName());
                CompletableFuture.runAsync(() ->

                                pubSubService.publishEvent(iLCoreConfig.getEventPubSubName(), iLCoreConfig.getTopicName(),
                                        reqInfo.getBody(),reqInfo.getMetadata()).subscribe(daprPubsubSubscriber),
                        auditLogTaskExecutor);
                log.debug("Successfully Published event in Kafka with pubsubTopic as {} ", iLCoreConfig.getTopicName());

        } catch (Exception e) {
            ilLogErrorMessage(e, "Error storing interface log.");
        }
    }

}
