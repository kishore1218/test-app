package com.hdfcbank.il.core.service;

import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.CoreSubscriber;

/**
 * @author venkat
 */
@Component
public class DaprPubsubSubscriber implements CoreSubscriber<Void> {
    private static final Logger log = LoggerFactory.getLogger(DaprPubsubSubscriber.class);

    private DaprPubsubSubscriber() {
    }

    public void onSubscribe(Subscription s) {
    }

    public void onNext(Void unused) {
    }

    public void onError(Throwable exception) {
        log.error("Throwable occurred while publishing data to Kafka using Dapr", exception);
    }

    public void onComplete() {
        log.debug("Pubsub Mono Complete");
    }
}
