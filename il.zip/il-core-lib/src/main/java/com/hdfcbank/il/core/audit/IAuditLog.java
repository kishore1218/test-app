package com.hdfcbank.il.core.audit;

import com.hdfcbank.il.core.model.ApiResponse;

/**
 *
 * @param <T>
 */
public interface IAuditLog {

    /**
     *
     * @param response
     */
    public void audit(ApiResponse response);

}
