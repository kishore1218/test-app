package com.hdfcbank.il.core.annotation;

import com.hdfcbank.il.core.audit.DefaultAuditLog;
import com.hdfcbank.il.core.audit.IAuditLog;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface AuditLog {

    /**
     *
     * @return
     */
    Class<? extends IAuditLog> strategy() ;
}
