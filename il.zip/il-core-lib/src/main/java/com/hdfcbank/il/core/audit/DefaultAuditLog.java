package com.hdfcbank.il.core.audit;

import com.hdfcbank.il.core.model.ApiRequest;
import com.hdfcbank.il.core.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;


/**
 *
 */
@Slf4j
public class DefaultAuditLog implements IAuditLog{

    public  static final DefaultAuditLog instance=new DefaultAuditLog();


    public static DefaultAuditLog getInstance(){
        return instance;
    }



    /**
     * @param response
     */
    @Override
    public void audit(ApiResponse response) {

    }
}
