package com.hdfcbank.il.core.model;

import lombok.Builder;
import lombok.Data;


/**
 *
 * @param <T>
 */
@Data
@Builder
public class ApiResponse<T> {

    private T response;

    private String host;
}
