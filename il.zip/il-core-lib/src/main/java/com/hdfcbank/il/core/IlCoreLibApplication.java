package com.hdfcbank.il.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IlCoreLibApplication {

	public static void main(String[] args) {
		SpringApplication.run(IlCoreLibApplication.class, args);
	}

}
