package com.hdfcbank.il.core.dto;

import lombok.Data;

@Data
public class DistributionState {
    String targetSystem;
    int lowerMod;
    int upperMod;
}
