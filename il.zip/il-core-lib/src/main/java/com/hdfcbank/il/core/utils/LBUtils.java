package com.hdfcbank.il.core.utils;

import com.hdfcbank.il.core.annotation.LoadBalanced;
import com.hdfcbank.il.core.model.ApiRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.BeanFactory;

import java.lang.reflect.Field;
import java.util.Map;

@Slf4j
public class LBUtils {

    /**
     *
     * @param annotation
     * @param args
     * @param beanFactory
     */
    public static void loadBalancer(LoadBalanced annotation, Object[] args, BeanFactory beanFactory) {
        var strategy = beanFactory.getBean(annotation.strategy());
        var req = (ApiRequest) args[0];
        var targetHost = (String) strategy.identifySwitch(req.getTxnId());
        log.info("identified target switch: - {}",targetHost);
        req.setHostName(targetHost);
    }

    /**
     *
     * @param field
     * @param args
     * @param beanFactory
     */
    public static void loadBalancer(Field field, Object[] args, BeanFactory beanFactory) {
        var annotation = field.getAnnotation(LoadBalanced.class);
        var strategy = beanFactory.getBean(annotation.strategy());
        var req = (ApiRequest) args[0];
        var targetHost =(String) strategy.identifySwitch(req.getTxnId());
        log.info("identified target switch: - {}",targetHost);
        req.setHostName(targetHost);
    }
}
