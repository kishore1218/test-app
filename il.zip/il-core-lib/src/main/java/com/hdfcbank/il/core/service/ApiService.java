package com.hdfcbank.il.core.service;

import com.hdfcbank.il.core.model.ApiRequest;
import com.hdfcbank.il.core.model.ApiResponse;

import java.util.Map;


/**
 *
 */
public interface ApiService {

    /**
     *
     * @param reqInfo
     * @return
     */
    public<T1,T2> ApiResponse<T2> process(ApiRequest<T1> reqInfo);
}
