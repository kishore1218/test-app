package com.hdfcbank.il.core.constants;

/**
 * @author venkat
 */
public interface CommonConstants {
    String X_REQUESTING_USER = "x-requesting-user";
    String PATH = "path";
    }
