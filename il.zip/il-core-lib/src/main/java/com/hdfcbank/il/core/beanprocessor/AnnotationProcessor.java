package com.hdfcbank.il.core.beanprocessor;

import com.hdfcbank.il.core.annotation.AuditLog;
import com.hdfcbank.il.core.annotation.LoadBalanced;
import com.hdfcbank.il.core.model.ApiResponse;
import com.hdfcbank.il.core.service.ApiService;
import com.hdfcbank.il.core.utils.AuditLogUtils;
import com.hdfcbank.il.core.utils.LBUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Proxy;
import java.util.Map;


/**
 *
 */
@Slf4j
@Component
public class AnnotationProcessor implements BeanPostProcessor {

    private ConfigurableListableBeanFactory configurableBeanFactory;

    @Autowired
    public AnnotationProcessor(ConfigurableListableBeanFactory beanFactory) {
        this.configurableBeanFactory = beanFactory;
    }

    /**
     * @param bean
     * @param beanName
     * @return
     * @throws BeansException
     */
//    @Override
//    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
//
//        if (bean instanceof ApiService service) {
//            var loadBalanceAnnotation = configurableBeanFactory.findAnnotationOnBean(beanName, LoadBalanced.class);
//            var auditLogAnnotation = configurableBeanFactory.findAnnotationOnBean(beanName, AuditLog.class);
//
//            if (loadBalanceAnnotation != null || auditLogAnnotation != null) {
//                ApiService proxy = (ApiService) Proxy.newProxyInstance(bean.getClass().getClassLoader(), new Class<?>[]{ApiService.class},
//                        (prxy, method, vars) -> {
//                            if (loadBalanceAnnotation!=null) {
//                                //apply given load balancer strategy and modify the target param
//                                LBUtils.loadBalancer(loadBalanceAnnotation, vars, configurableBeanFactory);
//                            }
//                            var response = method.invoke(bean, vars);
//                            if (auditLogAnnotation!=null) {
//                                AuditLogUtils.audit(auditLogAnnotation, configurableBeanFactory, (ApiResponse) response);
//                            }
//                            return response;
//                        });
//                return proxy;
//            }
//        }
//        return bean;
//    }


    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        ReflectionUtils.doWithFields(bean.getClass(), new AnnotationFieldCallBack(configurableBeanFactory, bean, beanName));
        return bean;
    }
}
