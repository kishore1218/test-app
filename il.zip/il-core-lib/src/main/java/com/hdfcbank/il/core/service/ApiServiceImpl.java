package com.hdfcbank.il.core.service;

import com.fyndna.common.constant.DaprHttpMethod;
import com.fyndna.common.context.Context;
import com.fyndna.common.factory.BindingServiceFactory;
import com.fyndna.common.type.WrapperException;
import com.hdfcbank.il.core.model.ApiRequest;
import com.hdfcbank.il.core.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;

import static com.hdfcbank.il.core.constants.CommonConstants.PATH;
import static com.hdfcbank.il.core.constants.CommonConstants.X_REQUESTING_USER;


/**
 *
 */
@Slf4j
public class ApiServiceImpl implements ApiService {

    @Autowired
    private BindingServiceFactory bindingServiceFactory;

    /**
     * @param reqInfo
     * @return
     */
    @Override
    public<T1,T2> ApiResponse<T2> process(ApiRequest<T1> reqInfo) {
        log.info("process request-{}",reqInfo);

        var res=(T2)callDestinationWithBinding((String) reqInfo.getBody(),reqInfo.getHostName());
        return ApiResponse.<T2>builder().response(res).host(reqInfo.getHostName()).build();
    }

    /**
     * method to call external destination systems like old switch or new switch using dapr binding.
     *
     * @return
     */
    public String callDestinationWithBinding(String request, String destBindingName) {
        String response;
        Map<String, String> metadata = new HashMap<>();
        metadata.put(PATH, "/reqpay/");
        metadata.put(X_REQUESTING_USER, Context.getRequestingUser());
        log.info("calling binding service...");
        try {
            response =
                    bindingServiceFactory
                            .getHttpBindingService()
                            .invokeBinding(
                                    destBindingName,
                                    DaprHttpMethod.POST,
                                    metadata,
                                    request,
                                    String.class);

        } catch (WrapperException e) {
            log.error("Exception occurred during output binding", e);
            throw new RuntimeException(e);
        }
        log.info("output binding response:{}", response);
        return response;
    }


}
