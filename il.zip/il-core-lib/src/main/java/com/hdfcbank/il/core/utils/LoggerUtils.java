package com.hdfcbank.il.core.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author venkat
 */
public class LoggerUtils {
    private static final Logger log = LoggerFactory.getLogger(LoggerUtils.class);
    private static final String WHILE_STRING = " while ";

    private LoggerUtils() {
    }

    public static void ilLogErrorMessage(Exception e, String message) {
        String exceptionClass = getExceptionClass(e);
        log.error(exceptionClass + WHILE_STRING + message , e);
    }

    private static String getExceptionClass(Exception e) {
        String exceptionClass = Exception.class.getSimpleName();
        if (e != null) {
            exceptionClass = e.getClass().getSimpleName();
        }

        return exceptionClass;
    }
}
