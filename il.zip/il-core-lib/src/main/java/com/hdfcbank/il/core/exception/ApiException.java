package com.hdfcbank.il.core.exception;

/**
 *
 */
public class ApiException extends RuntimeException{

    public ApiException(Throwable ex){
        super(ex);
    }

}
