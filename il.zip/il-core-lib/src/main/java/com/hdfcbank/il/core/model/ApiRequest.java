package com.hdfcbank.il.core.model;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

/**
 *
 * @param <T>
 */
@Data
@Builder
public class ApiRequest<T> {

    private String hostName;
    private String txnId;
    private T body;
    private Map<String,Object> metadata;
    private Class<?> outputType;
    //private HttpMethod; TODO: enable after adding the dapr client dependency


}
