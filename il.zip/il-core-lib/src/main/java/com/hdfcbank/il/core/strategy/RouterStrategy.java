package com.hdfcbank.il.core.strategy;

/**
 *
 */
public interface RouterStrategy<T1,T2> {

    /**
     *
     * @param input
     * @return
     */
    public T2 identifySwitch(T1 input);
}
