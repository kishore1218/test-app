package com.hdfcbank.il.core.beanprocessor;


import com.hdfcbank.il.core.annotation.AuditLog;
import com.hdfcbank.il.core.annotation.LoadBalanced;
import com.hdfcbank.il.core.model.ApiResponse;
import com.hdfcbank.il.core.service.ApiService;
import com.hdfcbank.il.core.utils.AuditLogUtils;
import com.hdfcbank.il.core.utils.LBUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Proxy;

/**
 *
 */
@Slf4j
public class AnnotationFieldCallBack implements ReflectionUtils.FieldCallback {

    private ConfigurableListableBeanFactory beanFactory;
    private Object bean;
    private String beanName;


    public AnnotationFieldCallBack(ConfigurableListableBeanFactory beanFactory, Object bean, String beanName){
        this.beanFactory=beanFactory;
        this.bean=bean;
        this.beanName=beanName;
    }

    /**
     * Perform an operation using the given field.
     *
     * @param field the field to operate on
     */
    @Override
    public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {

        if(field.isAnnotationPresent(LoadBalanced.class) || field.isAnnotationPresent(AuditLog.class)){
            Class<?> intf=field.getType();
            ReflectionUtils.makeAccessible(field);
            Object proxy= Proxy.newProxyInstance(bean.getClass().getClassLoader(), new Class<?>[]{intf},
                    (pxy,method,vars)->{
                        if(field.isAnnotationPresent(LoadBalanced.class)){
                            //apply given load balancer strategy and modify the target param
                            LBUtils.loadBalancer(field, vars,beanFactory);
                        }
                        var obj=beanFactory.getBean(ApiService.class);
                        var result=method.invoke(obj,vars);
                        if(field.isAnnotationPresent(AuditLog.class)){
                            var auditLogAnnotation = field.getAnnotation(AuditLog.class);
                            AuditLogUtils.audit(auditLogAnnotation, beanFactory, (ApiResponse) result);
                        }
                        return result;
                    });
            field.set(bean,proxy);
        }

    }
}
